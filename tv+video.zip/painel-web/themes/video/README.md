# painel-slides
Tema para painel do novo sga (www.novosga.org) feito para ser usado na prefeitura baseado no tema padrão do sistema
