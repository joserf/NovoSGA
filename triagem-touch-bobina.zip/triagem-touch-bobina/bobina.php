<?php 

if (in_array($_GET['q'], array('contar', 'zerar'))) {

    if ($_GET['q'] == 'contar') {
        $total = contar((int)$_GET['unidade']);
        echo json_encode(array('total' => $total));
        exit;
    }

    if ($_GET['q'] == 'zerar') {
    
        if ($_GET['senha'] == 'ergkdjughuisg') {
            $zerar = zerar((int)$_GET['unidade']);
            if ($zerar === true) {
                echo json_encode(array('status' => 'ok'));
                exit;
            } else {
                echo json_encode(array('status' => 'err', 'msg' => $zerar));
                exit;
            }        
        }
    }
} else {
    echo 'Comando nao encontrado!';
}


function contar($unidade = 1) {

    $mysqli = con();
    $result = $mysqli->query("SELECT contador FROM bobina WHERE unidade_id = " . $unidade);
    $row    = $result->fetch_array(MYSQLI_ASSOC);
    
    return $row['contador'];
    

/* numeric array */
$row = $result->fetch_array(MYSQLI_NUM);
} 

function zerar($unidade = null) {
    
    if ($unidade) {
        $mysqli = con();
        $sql    = 'UPDATE bobina SET contador = 0 WHERE unidade_id = ' . $unidade;
        $result = $mysqli->query($sql);
    }
    
    return true;
} 

function con() {

    $param = include "../../config/database.php"; 
    return new mysqli($param['host'], $param['user'], $param['password'], $param['dbname']);
    
}

