triagem-touch
=============

Triagem voltada para telas sensíveis ao toque
