/**
 * Novo SGA - Prioridades
 * @author Rogerio Lino <rogeriolino@gmail.com>
 */
var SGA = SGA || {};

SGA.Prioridades = {
    
};