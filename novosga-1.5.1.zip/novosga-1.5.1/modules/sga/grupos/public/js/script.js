/**
 * Novo SGA - Grupos
 * @author Rogerio Lino <rogeriolino@gmail.com>
 */
var SGA = SGA || {};

SGA.Grupos = {
    
};