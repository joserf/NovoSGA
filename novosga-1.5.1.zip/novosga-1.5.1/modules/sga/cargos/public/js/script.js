/**
 * Novo SGA - Cargos
 * @author Rogerio Lino <rogeriolino@gmail.com>
 */
var SGA = SGA || {};

SGA.Cargos = {
    
};